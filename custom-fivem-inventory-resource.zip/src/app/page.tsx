import { db } from "@/db";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

const features = [
  {
    title: "Drag & drop slots",
    desc: "Hold left click and drop an item into any other slot to move or stack it.",
  },
  {
    title: "Drop / Split / Separate / Give",
    desc: "Right click any item for the full context menu, including a type-in amount for Separate.",
  },
  {
    title: "45kg weight cap",
    desc: "Every item has its own weight. Players are hard capped at 45kg — the bar fills as you go.",
  },
  {
    title: "Give nearby players",
    desc: "Give opens a live list of nearby players with distance, then lets you pick the amount to hand over.",
  },
  {
    title: "Hunger & thirst",
    desc: "Thirst drains over ~1.5h, hunger over ~3h. Warnings at 50/25/10%, and starving/dehydration kills you at 0%.",
  },
  {
    title: "Starter kit",
    desc: "First time joiners automatically receive a phone, 3 bread and 3 bottles of water.",
  },
];

export default async function HomePage() {
  await db.execute(sql`select 1`);

  return (
    <main className="min-h-screen bg-[#0b0c0d] text-[#e9e9ea]">
      <div className="mx-auto max-w-4xl px-6 py-16">
        <p className="m-0 text-xs font-semibold uppercase tracking-[0.16em] text-[#3fa9a0]">
          FiveM Standalone Resource
        </p>
        <h1 className="mt-3 text-[clamp(2rem,5vw,3rem)] font-bold leading-[1.1]">
          ps-inventory
        </h1>
        <p className="mt-4 max-w-2xl text-[15px] leading-relaxed text-[#9a9aa0]">
          A lightweight, standalone drag &amp; drop inventory for your FiveM server —
          no framework, no database server required. Right click for Drop / Split /
          Separate / Give, a hard 45kg weight limit, and a full hunger &amp; thirst
          survival loop. The HUD is plain HTML/CSS/JS styled to look like a real game
          UI, not a web dashboard.
        </p>

        <div className="mt-8 flex flex-wrap items-center gap-3">
          <a
            href="/downloads/ps-inventory.zip"
            download
            className="rounded-md border border-[#3fa9a0]/40 bg-[#3fa9a0]/20 px-5 py-3 text-sm font-semibold text-[#e9e9ea] transition hover:bg-[#3fa9a0]/30"
          >
            Download ps-inventory.zip
          </a>
          <span className="text-xs text-[#6f6f74]">
            Drop the extracted folder straight into your <code className="text-[#9a9aa0]">resources</code> directory.
          </span>
        </div>

        <div className="mt-14 grid gap-4 sm:grid-cols-2">
          {features.map((f) => (
            <div
              key={f.title}
              className="rounded-lg border border-white/[0.08] bg-white/[0.03] p-5"
            >
              <h3 className="text-sm font-semibold text-[#f0f0f1]">{f.title}</h3>
              <p className="mt-2 text-[13px] leading-relaxed text-[#9a9aa0]">{f.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-14 rounded-lg border border-white/[0.08] bg-white/[0.03] p-6">
          <h2 className="text-sm font-semibold text-[#f0f0f1]">Setup</h2>
          <ol className="mt-3 list-decimal space-y-2 pl-5 text-[13px] leading-relaxed text-[#9a9aa0]">
            <li>Unzip and copy the <code className="text-[#c8c8ca]">ps-inventory</code> folder into your server's <code className="text-[#c8c8ca]">resources</code> folder.</li>
            <li>Add <code className="text-[#c8c8ca]">ensure ps-inventory</code> to your <code className="text-[#c8c8ca]">server.cfg</code>.</li>
            <li>Restart the server — no database setup needed, data is stored in a local JSON file.</li>
            <li>Press <code className="text-[#c8c8ca]">TAB</code> in game to open the inventory.</li>
          </ol>
          <p className="mt-4 text-[13px] text-[#6f6f74]">
            Full details, controls, config options and exports are documented in the
            README bundled inside the zip.
          </p>
        </div>
      </div>
    </main>
  );
}
