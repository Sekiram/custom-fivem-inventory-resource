local isOpen = false
local currentInventory = {}
local currentSecondary = {}
local currentDropId = nil
local hunger, thirst = 100.0, 100.0
local activeDrops = {} -- [dropId] = { coords = vector3, object = entity }

-- ===================== HELPERS =====================
local function ShowNotification(msg)
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName(msg)
    EndTextCommandThefeedPostTicker(false, true)
end

local function DrawText3D(coords, text)
    local onScreen, sx, sy = World3dToScreen2d(coords.x, coords.y, coords.z)
    if not onScreen then return end

    SetTextScale(0.32, 0.32)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry('STRING')
    SetTextCentre(true)
    AddTextComponentString(text)
    DrawText(sx, sy)
end

local function CheckThresholds(old, new, kind)
    if new == nil or old == nil then return end
    for _, threshold in ipairs(Config.NotifyThresholds) do
        if old > threshold and new <= threshold then
            ShowNotification(kind == 'hunger' and 'You are getting hungry.' or 'You are getting thirsty.')
        end
    end
    if new <= 0 and old > 0 then
        ShowNotification(kind == 'hunger' and 'You are starving, find food soon!' or 'You are dehydrated, find water soon!')
    end
end

local function GetHealthPercent()
    local ped = PlayerPedId()
    local max = GetEntityMaxHealth(ped)
    local cur = GetEntityHealth(ped)
    return math.floor(((cur - 100) / (max - 100)) * 100 + 0.5)
end

-- ===================== OPEN / CLOSE =====================
local function CloseInventory()
    isOpen = false
    currentDropId = nil
    currentSecondary = {}
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
end

local function OpenInventory(secondaryPayload)
    isOpen = true
    SetNuiFocus(true, true)

    local payload = {
        action = 'open',
        inventory = currentInventory,
        hunger = hunger,
        thirst = thirst,
        health = GetHealthPercent(),
        maxWeight = Config.MaxWeight,
        items = Config.Items,
        playerName = GetPlayerName(PlayerId()),
        playerId = GetPlayerServerId(PlayerId()),
    }

    if secondaryPayload then
        currentDropId = secondaryPayload.id
        currentSecondary = secondaryPayload.items or {}
        payload.secondary = currentSecondary
        payload.secondaryLabel = secondaryPayload.label
    end

    SendNUIMessage(payload)
end

RegisterCommand('psinventory', function()
    if isOpen then
        CloseInventory()
    else
        OpenInventory()
    end
end, false)

RegisterKeyMapping('psinventory', 'Open Inventory', 'keyboard', Config.OpenKey)

-- ===================== SERVER EVENTS =====================
RegisterNetEvent('psinv:client:init')
AddEventHandler('psinv:client:init', function(data)
    currentInventory = data.inventory or {}
    hunger = data.hunger or 100
    thirst = data.thirst or 100
end)

RegisterNetEvent('psinv:client:update')
AddEventHandler('psinv:client:update', function(data)
    currentInventory = data.inventory or {}

    CheckThresholds(hunger, data.hunger, 'hunger')
    CheckThresholds(thirst, data.thirst, 'thirst')

    hunger = data.hunger or hunger
    thirst = data.thirst or thirst

    if isOpen then
        SendNUIMessage({
            action = 'updateInventory',
            inventory = currentInventory,
            hunger = hunger,
            thirst = thirst,
            health = GetHealthPercent(),
            maxWeight = data.maxWeight or Config.MaxWeight,
        })
    end
end)

RegisterNetEvent('psinv:client:notify')
AddEventHandler('psinv:client:notify', function(msg, kind)
    ShowNotification(msg)
    if isOpen then
        SendNUIMessage({ action = 'notify', message = msg, kind = kind })
    end
end)

RegisterNetEvent('psinv:client:heal')
AddEventHandler('psinv:client:heal', function(amount)
    local ped = PlayerPedId()
    local max = GetEntityMaxHealth(ped)
    local cur = GetEntityHealth(ped)
    SetEntityHealth(ped, math.min(max, cur + amount))
end)

RegisterNetEvent('psinv:client:openSecondary')
AddEventHandler('psinv:client:openSecondary', function(payload)
    OpenInventory(payload)
end)

RegisterNetEvent('psinv:client:updateSecondary')
AddEventHandler('psinv:client:updateSecondary', function(items)
    currentSecondary = items or {}
    if isOpen then
        SendNUIMessage({ action = 'updateSecondary', secondary = currentSecondary })
    end
end)

-- ===================== FIRST INIT =====================
CreateThread(function()
    while not NetworkIsPlayerActive(PlayerId()) do Wait(200) end
    Wait(1500)
    TriggerServerEvent('psinv:server:init')
end)

-- ===================== HUNGER / THIRST DAMAGE =====================
CreateThread(function()
    while true do
        Wait(Config.StarvingDamageIntervalMs)
        if hunger <= 0 or thirst <= 0 then
            local ped = PlayerPedId()
            if not IsEntityDead(ped) then
                local cur = GetEntityHealth(ped)
                SetEntityHealth(ped, math.max(0, cur - Config.StarvingDamageAmount))
            end
        end
    end
end)

-- ===================== DROPPED BAGS (VISUAL + INTERACT) =====================
local function CreateDropProp(dropId, coords)
    if activeDrops[dropId] then return end

    local model = GetHashKey('prop_paper_bag01')
    RequestModel(model)
    local timeout = 0
    while not HasModelLoaded(model) and timeout < 200 do
        Wait(10)
        timeout = timeout + 1
    end

    local obj = CreateObject(model, coords.x, coords.y, coords.z + 0.05, false, false, false)
    PlaceObjectOnGroundProperly(obj)
    FreezeEntityPosition(obj, true)
    SetEntityAsMissionEntity(obj, true, true)
    SetModelAsNoLongerNeeded(model)

    activeDrops[dropId] = { coords = vector3(coords.x, coords.y, coords.z), object = obj }
end

local function RemoveDropProp(dropId)
    local drop = activeDrops[dropId]
    if drop then
        if DoesEntityExist(drop.object) then
            DeleteEntity(drop.object)
        end
        activeDrops[dropId] = nil
    end
end

RegisterNetEvent('psinv:client:createDrop')
AddEventHandler('psinv:client:createDrop', function(dropId, coords)
    CreateDropProp(dropId, coords)
end)

RegisterNetEvent('psinv:client:removeDrop')
AddEventHandler('psinv:client:removeDrop', function(dropId)
    RemoveDropProp(dropId)
end)

CreateThread(function()
    while true do
        local sleep = 800
        if not isOpen then
            local ped = PlayerPedId()
            local coords = GetEntityCoords(ped)
            local closestId, closestDist = nil, Config.DropInteractDistance

            for dropId, drop in pairs(activeDrops) do
                local dist = #(coords - drop.coords)
                if dist <= closestDist then
                    closestId = dropId
                    closestDist = dist
                end
            end

            if closestId then
                sleep = 0
                DrawText3D(activeDrops[closestId].coords + vector3(0.0, 0.0, 0.35), '[E] Open Bag')
                if IsControlJustPressed(0, 38) then
                    TriggerServerEvent('psinv:server:openDrop', closestId)
                end
            end
        end
        Wait(sleep)
    end
end)

-- ===================== DISABLE CONTROLS WHILE OPEN =====================
CreateThread(function()
    while true do
        if isOpen then
            DisableControlAction(0, 24, true)  -- attack
            DisableControlAction(0, 25, true)  -- aim
            DisableControlAction(0, 140, true) -- melee attack light
            DisableControlAction(0, 141, true) -- melee attack heavy
            DisableControlAction(0, 142, true) -- melee attack alternate
            DisableControlAction(0, 143, true) -- melee block
            DisableControlAction(0, 37, true)  -- weapon wheel
            DisableControlAction(0, 288, true) -- phone (X)
            DisableControlAction(0, 289, true) -- phone (Y)
            Wait(0)
        else
            Wait(250)
        end
    end
end)

-- ===================== NUI CALLBACKS =====================
RegisterNUICallback('close', function(_, cb)
    CloseInventory()
    cb('ok')
end)

RegisterNUICallback('getNearbyPlayers', function(_, cb)
    local players = {}
    local myPed = PlayerPedId()
    local myCoords = GetEntityCoords(myPed)

    for _, playerId in ipairs(GetActivePlayers()) do
        if playerId ~= PlayerId() then
            local ped = GetPlayerPed(playerId)
            local dist = #(myCoords - GetEntityCoords(ped))
            if dist <= Config.NearbyPlayerRange then
                table.insert(players, {
                    serverId = GetPlayerServerId(playerId),
                    name = GetPlayerName(playerId),
                    distance = math.floor(dist * 10) / 10,
                })
            end
        end
    end

    cb(players)
end)

RegisterNUICallback('moveItem', function(data, cb)
    local fromCtx = data.fromContext
    local toCtx = data.toContext

    if fromCtx == 'player' and toCtx == 'player' then
        TriggerServerEvent('psinv:server:moveItem', data.fromSlot, data.toSlot)
    elseif fromCtx == 'player' and toCtx == 'drop' and currentDropId then
        local item = currentInventory[tostring(data.fromSlot)]
        if item then
            TriggerServerEvent('psinv:server:moveToDrop', currentDropId, data.fromSlot, data.toSlot, item.amount)
        end
    elseif fromCtx == 'drop' and toCtx == 'player' and currentDropId then
        local item = currentSecondary[tostring(data.fromSlot)]
        if item then
            TriggerServerEvent('psinv:server:moveFromDrop', currentDropId, data.fromSlot, data.toSlot, item.amount)
        end
    end

    cb('ok')
end)

RegisterNUICallback('useItem', function(data, cb)
    TriggerServerEvent('psinv:server:useItem', data.slot)
    cb('ok')
end)

RegisterNUICallback('splitItem', function(data, cb)
    TriggerServerEvent('psinv:server:splitItem', data.slot)
    cb('ok')
end)

RegisterNUICallback('separateItem', function(data, cb)
    TriggerServerEvent('psinv:server:separateItem', data.slot, data.amount)
    cb('ok')
end)

RegisterNUICallback('dropItem', function(data, cb)
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    TriggerServerEvent('psinv:server:dropItem', data.slot, data.amount, { x = coords.x, y = coords.y, z = coords.z })
    cb('ok')
end)

RegisterNUICallback('giveItem', function(data, cb)
    TriggerServerEvent('psinv:server:giveItem', data.slot, data.amount, data.targetId)
    cb('ok')
end)
